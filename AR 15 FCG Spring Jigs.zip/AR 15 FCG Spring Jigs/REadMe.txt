                       ~~~~~AR-15 Spring jigs~~~~~by~~~~~wouldnt you like to know~~~~~

i used .031 music wire it seems light but may work i would suggest probably around .05 should be alot stiffer 
these were developed because shipping on fire control groups is outrageous so now you can make you some
get you a ghost snake ar-15 printed control group    

the hammer spring jig will work for the trigger spring but ghost snake should soon have printed springs for the
trigger and disconnector 

               V2 helps fix the crotch length after the spring is created it wanted to spring longer  
               
they only take 15min to print so dont be surprised if i leave abunch of different sizes with one recomended size
different wire will spring differently 
       
             ~~~~~~~~~~~~~~~~~~~~!!!PLEASE DONT TAKE YOUR EYE OUT!!!~~~~~~~~~~~~~~~~~~~~ 